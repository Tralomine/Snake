#pragma once

#include "game.h"

Game menu(Game game);
Game levelMenu(Game game);
void credit(SDL_Surface* screen);
void rules(SDL_Surface* screen);
