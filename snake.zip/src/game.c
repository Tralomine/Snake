#include <stdlib.h>
#include "../include/SDL/SDL.h"
#include "../include/SDL/SDL_image.h"
#include "../include/SDL/SDL_ttf.h"

#include "snake.h"
#include "display.h"
#include "button.h"
#include "game.h"

///joue le jeu solo
Game play(Game game)
{
    SDL_Surface *background, *time, *score;

    char scoreTexte[255], timeTexte[255];
    SDL_Rect scorePos, timePos;
    scorePos.y = 0;
    timePos.y = 0;

    Uint32 interval1, interval2, seconde1, seconde2;

    game = setupGame(game);

    Bool done = FALSE, retourMenu, replay;

    while (!done)
    {
        // message processing loop
        SDL_PollEvent(&(game.event));
        // check for messages
        switch (game.event.type)
        {
            // exit if the window is closed
            case SDL_QUIT:
                done = TRUE;
                break;

            // check for keypresses
            case SDL_KEYDOWN:
            {
                int touche = game.event.key.keysym.sym;
                // quitte si on appuie sur ECHAP
                if (touche == SDLK_ESCAPE)
                    done = TRUE;

                //si il peux tourner, il se pr�pare a tourner
                if(game.snake.dir == HAUT || game.snake.dir == BAS){
                    if(touche == SDLK_a) //'a' a la place de 'q' et 'w' a la place de 'z' parce que qwerty
                        game.snake.nextdir = GAUCHE;
                    if(touche == SDLK_d)
                        game.snake.nextdir = DROITE;
                }
                if(game.snake.dir == GAUCHE || game.snake.dir == DROITE){
                    if(touche == SDLK_w)
                        game.snake.nextdir = BAS;
                    if(touche == SDLK_s)
                        game.snake.nextdir = HAUT;
                }
                break;
            }
        }

        game = displayMap(game);
        displaySnake(game.screen, &(game.snake), 1);


        sprintf(scoreTexte, "Score : %i", game.score);
        score = TTF_RenderText_Blended(game.font, scoreTexte, game.color);
        scorePos.x = (LARGEUR-score->w);
        SDL_BlitSurface(score, NULL, game.screen, &scorePos);

        if(game.time > -1){
            sprintf(timeTexte, "Temp restant : %i", game.time);
            time = TTF_RenderText_Blended(game.font, timeTexte, game.color);
            timePos.x = (LARGEUR-time->w)/2;
            SDL_BlitSurface(time, NULL, game.screen, &timePos);
        }

        Sprite life;
        setSprite(&life, "texture/life.png");

        int x;
        if(game.snake.life>0)
            for(x=0;x<game.snake.life;x++){
                displaySprite(game.screen, &life, x*64, 0);
            }


        if(game.collision == 1){
            game.collision = 0;
            if(game.snake.life > 0)
                game.snake.life--;
            else
                break;
        }

        if(game.time == 0){
            break;
        }

        if(game.collision == 2){
            if(game.currentFruit==5){  //pasteque
                game.score+=2;
                game.snake.growWait+=3;
            }else if(game.currentFruit==0 && game.snake.taille>3)    //cerise
                game.snake.taille -= 2;
            else
                game.snake.growWait++;

            if(game.currentFruit==3 && game.snake.life < 3)
                game.snake.life++;

            game.score++;
            game.collision = 0;
            game.currentFruit = rand()%6;
            game = generation_fruit(game);
            game.speed = (int)(game.speed*0.95);
        }

        if(game.score > 1 && game.level > -1 && game.level < 4 ){

            Button nextLevel, back;
            setButton(&nextLevel, "texture/next.png", (LARGEUR-150)/2+80, HAUTEUR - 60);
            setButton(&back, "texture/back.png", (LARGEUR-150)/2-80, HAUTEUR - 60);
            SDL_Surface* background;
            background = IMG_Load("texture/screen/win.png");

            SDL_BlitSurface(background, NULL, game.screen, NULL);
            displayButton(nextLevel, game.screen);
            displayButton(back, game.screen);
            SDL_Flip(game.screen);

            done = FALSE;
            while(!done){
                SDL_WaitEvent(&game.event);
                if(buttonClicked(&nextLevel, &game.event)==SDL_BUTTON_LEFT){
                    retourMenu = FALSE;
                    done = TRUE;
                }
                if(buttonClicked(&back, &game.event)==SDL_BUTTON_LEFT){
                    retourMenu = TRUE;
                    done = TRUE;
                }
                switch (game.event.type){
                    case SDL_QUIT:
                        done = TRUE;
                        break;
                    case SDL_KEYDOWN:
                        if (game.event.key.keysym.sym == SDLK_ESCAPE)
                            done = TRUE;
                        break;
                }
            }
            destroyButton(&nextLevel);
            SDL_FreeSurface(background);

            game.win = TRUE;
            done = TRUE;
        }


        interval1 = SDL_GetTicks();
        if (interval1 - interval2 > game.speed){    //toutes les "vitesses" temps, on bouge le snake
            deplacement_snake(&game);
            interval2 = interval1;
        }

        seconde1 = SDL_GetTicks();
        if (seconde1 - seconde2 > 1000){      //toutes les secondes, on reduit le temps
            game.time--;
            seconde2 = seconde1;
        }

        // Refresh l'�cran
        SDL_Flip(game.screen);
    }

    if(game.win == FALSE)
        replay = gameOver(game.screen);

    if(replay == TRUE){
        replay = FALSE;
        game = setupGame(game);
        game = play(game);
    }

    if(game.win == TRUE && game.level < 3 && retourMenu == FALSE){
        game.level++;
        game = setupGame(game);
        game = play(game);
    }

    return game;
}

///joue le jeu multi
Game playMulti(Game game)
{
    SDL_Surface* background;
    background = IMG_Load("texture/screen/load_multi.png");
    Button play;
    setButton(&play, "texture/play.png", (LARGEUR-150)/2, HAUTEUR - 60);

    SDL_BlitSurface(background, NULL, game.screen, NULL);
    displayButton(play, game.screen);
    SDL_Flip(game.screen);

    Bool done = FALSE;
    while(!done){
        SDL_WaitEvent(&game.event);
        if(buttonClicked(&play, &game.event)==SDL_BUTTON_LEFT)
           done = TRUE;
        switch (game.event.type){
            case SDL_QUIT:
                done = TRUE;
                break;
            case SDL_KEYDOWN:
                if (game.event.key.keysym.sym == SDLK_ESCAPE)
                    done = TRUE;
                break;
        }
    }
    destroyButton(&play);
    SDL_FreeSurface(background);

    done = FALSE;

    while (!done)
    {
        // message processing loop
        SDL_PollEvent(&(game.event));
        // check for messages
        switch (game.event.type){
            // exit if the window is closed
            case SDL_QUIT:
                done = TRUE;
                break;

            // check for keypresses
            case SDL_KEYDOWN:
            {
                int touche = game.event.key.keysym.sym;
                // quitte si on appuie sur ECHAP
                if (touche == SDLK_ESCAPE)
                    done = TRUE;

                //si il peux tourner, il se pr�pare a tourner
                if(game.snake.dir == HAUT || game.snake.dir == BAS){
                    if(touche == SDLK_a) //'a' a la place de 'q' et 'w' a la place de 'z' parce que qwerty
                        game.snake.nextdir = GAUCHE;
                    if(touche == SDLK_d)
                        game.snake.nextdir = DROITE;
                }
                if(game.snake.dir == GAUCHE || game.snake.dir == DROITE){
                    if(touche == SDLK_w)
                        game.snake.nextdir = BAS;
                    if(touche == SDLK_s)
                        game.snake.nextdir = HAUT;
                }
                //deuxiemme serpent
                if(game.snake2.dir == HAUT || game.snake2.dir == BAS){
                    if(touche == SDLK_k)
                        game.snake2.nextdir = GAUCHE;
                    if(touche == SDLK_SEMICOLON) //qwerty et le m...
                        game.snake2.nextdir = DROITE;
                }
                if(game.snake2.dir == GAUCHE || game.snake2.dir == DROITE){
                    if(touche == SDLK_o)
                        game.snake2.nextdir = BAS;
                    if(touche == SDLK_l)
                        game.snake2.nextdir = HAUT;
                }
                break;
            }
        }

        // DEBUT DESSIN

        game = displayMap(game);
        displaySnake(game.screen, &(game.snake), 1);
        displaySnake(game.screen, &(game.snake2), 2);

        if(game.collision == 1){
            game.collision = 0;
            break;
        }
        //collision du 2eme
        if(game.collision2 == 1){
            game.collision2 = 0;
            break;
        }

        if(game.collision == 2){
            if(game.currentFruit==5){  //pasteque
                game.score+=3;
                game.snake.growWait+=3;
            }else if(game.currentFruit==0 && game.snake.taille>3){    //cerise
                game.snake.taille -= 2;
            }else{
                game.snake.growWait++;
            }
            game.collision = 0;
            game.currentFruit = rand()%6;
            game = generation_fruit(game);
            game.speed = (int)(game.speed*0.95);
        }
        //fruit du 2eme
        if(game.collision2 == 2){
            if(game.currentFruit==5){  //pasteque
                game.score+=3;
                game.snake2.growWait+=3;
            }else if(game.currentFruit==0 && game.snake2.taille>3){    //cerise
                game.snake2.taille -= 2;
            }else{
                game.snake2.growWait++;
            }
            game.collision2 = 0;
            game.currentFruit = rand()%6;
            game = generation_fruit(game);
            game.speed = (int)(game.speed*0.95);
        }


        Uint32 interval1, interval2;
        interval1 = SDL_GetTicks();
        if (interval1 - interval2 > game.speed)
        {
            deplacement_snake(&game);
            interval2 = interval1;
        }

        // Refresh l'�cran
        SDL_Flip(game.screen);
    }

    gameOver(game.screen);

    return game;
}

///affiche les murs et les fruits en fonction de la carte
Game displayMap(Game game)
{
    Sprite wall, background;
    setSprite(&wall, "texture/brickWall.png");
    setSprite(&background, "texture/background.png");
    LargeSprite fruit;
    setLargeSprite(&fruit, "texture/fruit.png", 6, game.currentFruit);
    int x, y;

    for(x=0;x<TAILLEX;x++){
        for(y=0;y<TAILLEY;y++){
            displaySprite(game.screen, &background, x*TAILLESPRITE, y*TAILLESPRITE);
            if(game.levelMap[x][y]==MUR)
                displaySprite(game.screen, &wall, x*TAILLESPRITE, y*TAILLESPRITE);
            if(game.levelMap[x][y]==FRUIT)
                displayLargeSprite(game.screen, &fruit, x*TAILLESPRITE, y*TAILLESPRITE);
        }
    }
    destroySprite(&wall);
    destroySprite(&background);
    destroyLargeSprite(&fruit);

    return game;
}


///genere un nouveau fruit sur une case vide
Game generation_fruit(Game game)
{
    int fruit=0, fruit_x, fruit_y;
    int i;
    while(fruit==0){
        fruit_x=rand()%TAILLEX;
        fruit_y=rand()%TAILLEY;
        if(game.levelMap[fruit_x][fruit_y] == VIDE){
            fruit=1;
        }
        //pas de fruit sur le serpent !
        for(i=0;i<game.snake.taille;i++){
            if(game.snake.snake[i].x == fruit_x && game.snake.snake[i].y == fruit_y){
                fruit = 0;
                break;
            }
        }
        //pas de fruits sur le 2eme serpent non plus !
        if(game.multiplayer == TRUE){
            for(i=0;i<game.snake2.taille;i++){
                if(game.snake2.snake[i].x == fruit_x && game.snake2.snake[i].y == fruit_y){
                    fruit = 0;
                    break;
                }
            }
        }
    }
    game.levelMap[fruit_x][fruit_y] = FRUIT;

    return game;
}

///initialize le jeu solo
Game setupGame(Game game)
{
    int x=0, y=0, dir;
    dir = rand()%4;
    switch(dir){
        case 0:
            x++;
            game.snake.dir = GAUCHE;
            game.snake.nextdir = GAUCHE;
            break;
        case 1:
            y++;
            game.snake.dir = BAS;
            game.snake.nextdir = BAS;
            break;
        case 2:
            x--;
            game.snake.dir = DROITE;
            game.snake.nextdir = DROITE;
            break;
        case 3:
            y--;
            game.snake.dir = HAUT;
            game.snake.nextdir = HAUT;
            break;
    }

    game.snake.snake[0].x = TAILLEX/2;
    game.snake.snake[0].y = TAILLEY/2;
    game.snake.snake[1].x = TAILLEX/2+x;
    game.snake.snake[1].y = TAILLEY/2+y;

    game.snake.taille = 2;
    game.snake.growWait = 2;

    game = loadLevel(game);  //on charge le niveau

    game.time = -1;

    if(game.level == 3)
        game.time = 100;

    game.currentFruit = rand()%6;

    game.score = 0;
    game.speed = 400;

    game.snake.life = 1;

    game.win = FALSE;

    return game;
}

///initialize le jeu en multi
Game setupGameMulti(Game game)
{
    int x=0, y=0, dir;
    dir = rand()%4;
    switch(dir){
        case 0:
            x++;
            game.snake.dir = GAUCHE;
            game.snake.nextdir = GAUCHE;
            break;
        case 1:
            y++;
            game.snake.dir = BAS;
            game.snake.nextdir = BAS;
            break;
        case 2:
            x--;
            game.snake.dir = DROITE;
            game.snake.nextdir = DROITE;
            break;
        case 3:
            y--;
            game.snake.dir = HAUT;
            game.snake.nextdir = HAUT;
            break;
    }

    dir = rand()%4; //on fait la direction du 2eme aleatoire aussi
    switch(dir){
        case 0:
            x++;
            game.snake2.dir = GAUCHE;
            game.snake2.nextdir = GAUCHE;
            break;
        case 1:
            y++;
            game.snake2.dir = BAS;
            game.snake2.nextdir = BAS;
            break;
        case 2:
            x--;
            game.snake2.dir = DROITE;
            game.snake2.nextdir = DROITE;
            break;
        case 3:
            y--;
            game.snake2.dir = HAUT;
            game.snake2.nextdir = HAUT;
            break;
    }

    //on mets une map basique en multi
    for(x=0;x<TAILLEX;x++){
        for(y=0;y<TAILLEY;y++){
            if(x==0 || x==TAILLEX-1 || y==0 || y==TAILLEY-1)
                game.levelMap[x][y] = MUR;
            else
                game.levelMap[x][y] = VIDE;
        }
    }

    game.snake.snake[0].x = 5;
    game.snake.snake[0].y = 5;
    game.snake.snake[1].x = 5+x;
    game.snake.snake[1].y = 5+y;

    game.snake2.snake[0].x = 9;
    game.snake2.snake[0].y = 9;
    game.snake2.snake[1].x = 9+x;
    game.snake2.snake[1].y = 9+y;

    game.snake2.taille = 1;
    game.snake2.growWait = 2;

    game.snake.taille = 1;
    game.snake.growWait = 2;

    game.currentFruit = rand()%6;


    game.score = 0;
    game.speed = 400;

    game = generation_fruit(game);

    return game;
}

///charge un niveau a partir d'un fichier, et le stock dans la carte
Game loadLevel(Game game)
{
    FILE* level;
    if(game.level == -1)
        level = fopen("levels/infinity.txt", "r");
    else{
        char temp[32];
        sprintf(temp, "levels/level%i.txt", game.level);
        level = fopen(temp, "r");
    }

    rewind(level);

    int x, y;
    for(x=0;x<TAILLEX;x++){
        for(y=0;y<TAILLEY;y++){
            char c;
            c = fgetc(level);
            switch(c){
                case '0':
                    game.levelMap[x][y] = VIDE;
                    break;
                case '1':
                    game.levelMap[x][y] = MUR;
                    break;
            }
        }
        fgetc(level); //on supprimme le \n a la fin de chaques lignes
    }

    game = generation_fruit(game);

    return game;
}

Bool gameOver(SDL_Surface* screen)
{
    SDL_Surface* gameOver;
    gameOver = IMG_Load("texture/screen/gameOver.png");
    Button back, replay;
    setButton(&back, "texture/back.png", (LARGEUR-150)/2-80, HAUTEUR - 60);
    setButton(&replay, "texture/replay.png", (LARGEUR-150)/2+80, HAUTEUR - 60);

    SDL_BlitSurface(gameOver, NULL, screen, NULL);
    displayButton(back, screen);
    displayButton(replay, screen);
    SDL_Flip(screen);

    SDL_Event event;
    Bool done = FALSE, playAgain = FALSE;
    while(!done){
        SDL_WaitEvent(&event);
        if(buttonClicked(&replay, &event)==SDL_BUTTON_LEFT){
            playAgain = TRUE;
            done = TRUE;
        }
        if(buttonClicked(&back, &event)==SDL_BUTTON_LEFT){
            playAgain = FALSE;
            done = TRUE;
        }
        switch (event.type){
            case SDL_QUIT:
                done = TRUE;
                break;
            case SDL_KEYDOWN:
                if (event.key.keysym.sym == SDLK_ESCAPE)
                    done = TRUE;
                break;
        }
    }

    destroyButton(&back);
    destroyButton(&replay);
    SDL_FreeSurface(gameOver);

    return playAgain;
}
