#include <stdlib.h>
#include "../include/SDL/SDL.h"
#include "../include/SDL/SDL_image.h"

#include "const.h"
#include "snake.h"
#include "button.h"
#include "game.h"

#include "menu.h"

///g�re le choix entre les diff�rents types de jeux/les cr�dits/l'aide


//----------------GENERATION MENU PRINCIPAL & GESTION CLICK -----------------

Game menu(Game game)
{
    Button singlePlayer, multiPlayer, help, credits, quit;
    setButton(&singlePlayer, "texture/buttonSinglePlayer.png", 10, 250);
    setButton(&multiPlayer, "texture/buttonMultiPlayer.png", 10, 350);
    setButton(&help, "texture/buttonHelp.png", 10, 450);
    setButton(&credits, "texture/buttonCredits.png", 10, 550);
    setButton(&quit, "texture/buttonQuit.png", 10, 650);

    SDL_Surface *background, *Eater, *temp;
    temp = SDL_CreateRGBSurface(NULL, LARGEUR, HAUTEUR, 32, 0, 0, 0, 0);

    Eater = IMG_Load("texture/Eater.png");
    background = IMG_Load("texture/screen/background_menu.png");

    SDL_Rect EaterPos;  //Position serpent menu "mangeur" de bouton

    int x;

    Bool done = FALSE; // DONE => Permet l'arret de la boucle infinie
    while(!done)
    {
        //afficher l'�cran
        SDL_BlitSurface(background, NULL, game.screen, NULL);
        displayButton(singlePlayer, game.screen);
        displayButton(multiPlayer, game.screen);
        displayButton(credits, game.screen);
        displayButton(help, game.screen);
        displayButton(quit, game.screen);
        SDL_Flip(game.screen);

        //event checking
        SDL_WaitEvent(&(game.event));

        //Gestion click
        if(buttonClicked(&quit, &(game.event))==SDL_BUTTON_LEFT){
            SDL_BlitSurface(game.screen, NULL, temp, NULL);
            EaterPos.y = quit.pos.y-26;
            for(x=-768;x<-220;x++){
                SDL_BlitSurface(temp, NULL, game.screen, NULL);
                EaterPos.x = x;
                SDL_BlitSurface(Eater, NULL, game.screen, &EaterPos);
                SDL_Flip(game.screen);
            }
            done = TRUE;
        }
        switch (game.event.type){
            case SDL_QUIT:      //on quitte si on ferme la fenetre (la B.A.Z)
                done = TRUE;
                break;
            case SDL_KEYDOWN:   // quitte si on appuie sur ECHAP
                if (game.event.key.keysym.sym == SDLK_ESCAPE)
                    done = TRUE;
                break;
        }
        if(buttonClicked(&singlePlayer, &(game.event))==SDL_BUTTON_LEFT){
            SDL_BlitSurface(game.screen, NULL, temp, NULL);
            EaterPos.y = singlePlayer.pos.y-26;
            for(x=-768;x<-220;x++){
                SDL_BlitSurface(temp, NULL, game.screen, NULL);
                EaterPos.x = x;
                SDL_BlitSurface(Eater, NULL, game.screen, &EaterPos);
                SDL_Flip(game.screen);
            }
            game.multiplayer = FALSE;
            game = levelMenu(game);
        }
        if(buttonClicked(&multiPlayer, &(game.event))==SDL_BUTTON_LEFT){
            SDL_BlitSurface(game.screen, NULL, temp, NULL);
            EaterPos.y = multiPlayer.pos.y-26;
            for(x=-768;x<-220;x++){
                SDL_BlitSurface(temp, NULL, game.screen, NULL);
                EaterPos.x = x;
                SDL_BlitSurface(Eater, NULL, game.screen, &EaterPos);
                SDL_Flip(game.screen);
            }
            game.multiplayer = TRUE;
            game = setupGameMulti(game);
            game = playMulti(game);
        }

        if(buttonClicked(&help, &(game.event))==SDL_BUTTON_LEFT){
            SDL_BlitSurface(game.screen, NULL, temp, NULL);
            EaterPos.y = help.pos.y-26;
            for(x=-768;x<-220;x++){
                SDL_BlitSurface(temp, NULL, game.screen, NULL);
                EaterPos.x = x;
                SDL_BlitSurface(Eater, NULL, game.screen, &EaterPos);
                SDL_Flip(game.screen);
            }
            rules(game.screen);
        }

        if(buttonClicked(&credits, &(game.event))==SDL_BUTTON_LEFT){
            SDL_BlitSurface(game.screen, NULL, temp, NULL);
            EaterPos.y = credits.pos.y-26;
            for(x=-768;x<-220;x++){
                SDL_BlitSurface(temp, NULL, game.screen, NULL);
                EaterPos.x = x;
                SDL_BlitSurface(Eater, NULL, game.screen, &EaterPos);
                SDL_Flip(game.screen);
            }
            credit(game.screen);
        }
    }

    //---LIBERATION MEMOIRE BOUTONS---
    destroyButton(&singlePlayer);
    destroyButton(&multiPlayer);
    destroyButton(&help);
    destroyButton(&credits);
    destroyButton(&quit);
    //---LIBERATION MEMOIRE BOUTONS---

    return game;
}
//----------------GENERATION MENU PRINCIPAL & GESTION CLICK -----------------


///affiche le menu de choix entre les diff�rents niveaux solo
Game levelMenu(Game game)
{
    int x, y;
    SDL_Surface* background;

    background = IMG_Load("texture/screen/load_sing.png");
    Button playLvl;
    setButton(&playLvl, "texture/play.png", (LARGEUR-150)/2, HAUTEUR - 60);

    SDL_BlitSurface(background, NULL, game.screen, NULL);
    displayButton(playLvl, game.screen);
    SDL_Flip(game.screen);

    Bool done = FALSE;
    while(!done){
        SDL_WaitEvent(&game.event);
        if(buttonClicked(&playLvl, &game.event)==SDL_BUTTON_LEFT)
           done = TRUE;
        switch (game.event.type){
            case SDL_QUIT:
                done = TRUE;
                break;
            case SDL_KEYDOWN:
                if (game.event.key.keysym.sym == SDLK_ESCAPE)
                    done = TRUE;
                break;
        }
    }
    destroyButton(&playLvl);
    SDL_FreeSurface(background);

    background = IMG_Load("texture/screen/backgroundLevelMenu.png");

    Button backMenu, levels[4], infinity;
    for(x=0;x<2;x++){
        for(y=0;y<2;y++){
            char temp[32];
            sprintf(temp, "texture/lvl%i.png", x*2+y);
            setButton(&levels[x*2+y], temp, y*215+100, x*217+191);
        }
    }
    setButton(&backMenu, "texture/back.png", (LARGEUR-150)/2, HAUTEUR - 60);
    setButton(&infinity, "texture/levelInf.png", LARGEUR-492, 188);


    SDL_BlitSurface(background, NULL, game.screen, NULL);
    SDL_BlitSurface(backMenu.surface, NULL, game.screen, &backMenu.pos);
    for(x=0;x<4;x++){SDL_BlitSurface(levels[x].surface, NULL, game.screen, &levels[x].pos);}
    SDL_BlitSurface(infinity.surface, NULL, game.screen, &infinity.pos);

    SDL_Flip(game.screen);


    done = FALSE;
    Bool retourMenu = TRUE;  //si retourMenu == True, on ne joue pas de level
    while(!done){
        SDL_WaitEvent(&game.event);
        if(buttonClicked(&backMenu, &game.event)==SDL_BUTTON_LEFT)
           done = TRUE;
        if(buttonClicked(&infinity, &game.event)==SDL_BUTTON_LEFT){
            done = TRUE;
            retourMenu = FALSE;
            game.level=-1;
        }
        for(x=0;x<4;x++){
            if(buttonClicked(&levels[x], &game.event)==SDL_BUTTON_LEFT){
                done = TRUE;
                retourMenu = FALSE;
                game.level=x;
            }
        }
        switch (game.event.type){
            case SDL_QUIT:  //Si click sur croix
                done = TRUE;
                break;
            case SDL_KEYDOWN:
                if (game.event.key.keysym.sym == SDLK_ESCAPE)   //Si click Echap
                    done = TRUE;
                break;
        }
    }

    if(!retourMenu)
        game = play(game);

    destroyButton(&backMenu);
    for(x=0;x<4;x++){destroyButton(&levels[x]);}
    destroyButton(&infinity);
    return game;
}

///affiche l'�cran d'aide
void rules(SDL_Surface* screen)
{
    SDL_Surface* background;
    background = IMG_Load("texture/screen/rules.png");
    Button back;
    setButton(&back, "texture/back.png", (LARGEUR-150)/2, HAUTEUR - 60);

    SDL_BlitSurface(background, NULL, screen, NULL);
    displayButton(back, screen);
    SDL_Flip(screen);

    SDL_Event event;
    Bool done = FALSE;
    while(!done){
        SDL_WaitEvent(&event);
        if(buttonClicked(&back, &event)==SDL_BUTTON_LEFT)//Si click gauche sur bouton
           done = TRUE;
        switch (event.type){
            case SDL_QUIT:
                done = TRUE;
                break;
            case SDL_KEYDOWN:
                if (event.key.keysym.sym == SDLK_ESCAPE)
                    done = TRUE;
                break;
        }
    }
    destroyButton(&back);
    SDL_FreeSurface(background);
}

///affiche l'�cran des cr�dits
void credit(SDL_Surface* screen)
{
    SDL_Surface* background;
    background = IMG_Load("texture/screen/credits.png");
    Button back;
    setButton(&back, "texture/back.png", (LARGEUR-150)/2, HAUTEUR - 60);

    SDL_BlitSurface(background, NULL, screen, NULL);
    displayButton(back, screen);
    SDL_Flip(screen);

    SDL_Event event;
    Bool done = FALSE;
    while(!done){
        SDL_WaitEvent(&event);
        if(buttonClicked(&back, &event)==SDL_BUTTON_LEFT)
           done = TRUE;
        switch (event.type){
            case SDL_QUIT:
                done = TRUE;
                break;
            case SDL_KEYDOWN:
                if (event.key.keysym.sym == SDLK_ESCAPE)
                    done = TRUE;
                break;
        }
    }
    destroyButton(&back);
    SDL_FreeSurface(background);
}
