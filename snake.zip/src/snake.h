#pragma once

#include "const.h"

typedef enum {VIDE, MUR, FRUIT, SNAKE} Map;
typedef enum {HAUT, BAS, DROITE, GAUCHE} Direction;

typedef struct{
    int x, y;
}Point;

typedef struct{
    Point snake[TAILLE_SNAKE_MAX];
    int taille, growWait;
    Direction dir, nextdir;
    int life;
}Snake;


void displaySnake(SDL_Surface* screen, Snake* snake, int numero);
void deplacement_snake(void* temp);
