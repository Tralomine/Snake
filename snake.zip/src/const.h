#pragma once

#define TAILLEX 16
#define TAILLEY 12
#define TAILLESPRITE 64

#define LARGEUR TAILLESPRITE * TAILLEX
#define HAUTEUR TAILLESPRITE * TAILLEY


#define TAILLE_SNAKE_MAX 999

typedef enum {FALSE, TRUE} Bool;
